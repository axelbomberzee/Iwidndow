# Spinz.io — cliente web estático (captura 2018)

Este paquete contiene los archivos públicos del **cliente** servidos por la captura seleccionada del 30 de noviembre de 2018, 22:20:22 UTC.

## Incluye

- `index.html`: HTML de la pantalla inicial y configuración del cliente.
- `asset/app.css`: hoja de estilos del cliente.
- `asset/app.js`: bundle JavaScript que se entregaba al navegador (minificado en el sitio original).
- `asset/image/`: 149 recursos gráficos del cliente que fueron conservados en la captura.

## Limpieza aplicada

Se eliminaron los anuncios, la promoción de otro juego, el enlace de «More IO Games», Google Analytics, Sentry/Raven, Curse CDM y el widget de pago Xsolla. El paquete no contiene enlaces ni código inyectado de Wayback Machine.

Se conserva `//c.n.m28.io/sdk.js` porque era parte del descubrimiento de servidores del propio juego, no publicidad. Si ya no está disponible, el cliente mostrará su interfaz pero no podrá encontrar partidas.

## Ejecutar localmente

Desde esta carpeta, iniciar un servidor estático:

```bash
python3 -m http.server 8080
```

Luego abrir `http://localhost:8080`.

## Límite de la recuperación

Una captura web solo entrega lo que recibió el navegador. No incluye el backend, la base de datos, autenticación ni los servidores WebSocket/matchmaking originales. Tampoco se publicó el código fuente sin minificar ni los source maps del bundle; por eso `asset/app.js` se conserva como el JavaScript de producción que se entregaba públicamente.
